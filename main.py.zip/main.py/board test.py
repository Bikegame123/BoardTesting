import pygame
import random
import sys
import json
import math
from perlin_noise import PerlinNoise

# Initialize Pygame
pygame.init()
pygame.mixer.init()

# --- [MODIFIED] Initialize Joystick System at Start ---
pygame.joystick.init()

# Load sounds
try:
    dead_sound = pygame.mixer.Sound("dead.wav")
    pygame.mixer.music.load("music loop.wav")
    print("Sounds loaded successfully")
except pygame.error as e:
    print(f"Sound files not found: {e}")
    dead_sound = None

# --- Constants ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
PLAYER_SPEED = 5
OBSTACLE_SPEED = 3
POWERUP_SPEED = 3
NEON_BLUE = (0, 255, 255)
NEON_PINK = (255, 0, 255)
NEON_GREEN = (0, 255, 0)
BLACK = (10, 10, 10)
WHITE = (255, 255, 255)
ORANGE = (255, 165, 0)
RED = (255, 0, 0)
GOLD = (255, 215, 0)
PURPLE = (180, 0, 255)
GREY = (150, 150, 150)

SCOREBOARD_FILE = "scoreboard.json"

# --- Fire color palette for improved visuals ---
FIRE_COLORS = [
    (255, 255, 220), # Bright Core (Creamy White)
    (255, 215, 0),   # Yellow/Gold
    (255, 140, 0),   # Orange
    (200, 50, 0),    # Dark Red
    (40, 20, 10)     # Fading Embers/Smoke
]


# Set up the display
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Neon Runner")
clock = pygame.time.Clock()

# --- Load Custom Font ---
try:
    font = pygame.font.Font("PressStart2P-Regular.ttf", 20)
    big_font = pygame.font.Font("PressStart2P-Regular.ttf", 40)
    small_font = pygame.font.Font("PressStart2P-Regular.ttf", 14)
except pygame.error:
    print("Font file 'PressStart2P-Regular.ttf' not found! Falling back to default.")
    font = pygame.font.SysFont("monospace", 30)
    big_font = pygame.font.SysFont("monospace", 60)
    small_font = pygame.font.SysFont("monospace", 18)

# --- Full list of 21 Cybersecurity questions ---
questions = [
    {"question": "What does 'phishing' mean?", "options": ["A scam to steal personal info", "A type of fishing lure", "A network error message"], "correct": 0},
    {"question": "What is a firewall for?", "options": ["To block bad internet traffic", "To make your computer warmer", "To stop real fires"], "correct": 0},
    {"question": "What is a 'VPN' used for?", "options": ["Encrypting your connection", "A type of virus scan", "To speed up your PC"], "correct": 0},
    {"question": "Which of these is the strongest password?", "options": ["password123", "FluffyTheDog", "R#ck3t!Ship9"], "correct": 2},
    {"question": "What is SAFE to share with a stranger online?", "options": ["Your home address", "Your favorite game", "Your phone number"], "correct": 1},
    {"question": "A computer 'virus' is a type of...?", "options": ["Bad software", "Computer dust", "A slow internet connection"], "correct": 0},
    {"question": "If a stranger online asks for your picture, you should...", "options": ["Send it to them", "Tell a parent or guardian", "Ask for their picture first"], "correct": 1},
    {"question": "A pop-up says 'YOU WON! CLICK HERE!'. What should you do?", "options": ["Click to get your prize!", "Close the window or tell an adult", "Enter your name to see"], "correct": 1},
    {"question": "Being mean to someone in an online game is called...?", "options": ["Good sportsmanship", "Cyberbullying", "Just joking"], "correct": 1},
    {"question": "What does an antivirus program do?", "options": ["Protects from bad software", "Cleans your screen", "Makes games faster"], "correct": 0},
    {"question": "Is it safe to use free public WiFi for online banking?", "options": ["No, it can be risky", "Yes, it's super fast", "Only if you pay for it"], "correct": 0},
    {"question": "What does the 's' in 'https://' mean at the start of a web address?", "options": ["Secure", "Super", "Slow"], "correct": 0},
    {"question": "Should you ever share your password with your best friend?", "options": ["No, never", "Yes, if they promise not to tell", "Only on their birthday"], "correct": 0},
    {"question": "What is a 'Trojan Horse' in computing?", "options": ["A virus disguised as a good program", "An ancient statue", "A type of computer case"], "correct": 0},
    {"question": "What does 'spam' email usually contain?", "options": ["Junk ads and scams", "Secret messages", "Important school news"], "correct": 0},
    {"question": "What is a 'digital footprint'?", "options": ["The trail of data you leave online", "A type of computer shoe", "A glowing computer mouse"], "correct": 0},
    {"question": "If an app asks for permission to see your contacts, should you always say yes?", "options": ["No, think if it really needs it", "Yes, all apps need it", "Only if the app is blue"], "correct": 0},
    {"question": "What is 'clickbait'?", "options": ["A tricky headline to make you click", "A special button in a game", "A type of computer virus"], "correct": 0},
    {"question": "Where should you save your passwords?", "options": ["On a sticky note on your monitor", "In a secure password manager", "In a text file on your desktop"], "correct": 1},
    {"question": "What is Two-Factor Authentication (2FA)?", "options": ["A second login step for extra safety", "A way to log in twice as fast", "A type of game controller"], "correct": 0},
    {"question": "If you download a game from a weird website, it might contain...?", "options": ["Malware", "Extra bonus levels", "A faster internet connection"], "correct": 0},
]

# --- Helper Functions ---
class Particle:
    def __init__(self, x, y, color, size, life, angle, speed, color_palette=None):
        self.x, self.y, self.color, self.size, self.life, self.angle, self.speed = x, y, color, size, life, angle, speed
        self.initial_life = life if life > 0 else 1
        self.color_palette = color_palette

    def update(self):
        self.life -= 1
        self.size = max(0, self.size - 0.1)
        self.x += math.cos(self.angle) * self.speed
        self.y += math.sin(self.angle) * self.speed
        
        if self.color_palette:
            life_ratio = self.life / self.initial_life
            progress = 1.0 - life_ratio
            
            idx_float = progress * (len(self.color_palette) - 1)
            idx1 = int(idx_float)
            idx2 = min(idx1 + 1, len(self.color_palette) - 1)
            blend = idx_float - idx1
            
            r1, g1, b1 = self.color_palette[idx1]
            r2, g2, b2 = self.color_palette[idx2]
            
            r = r1 + (r2 - r1) * blend
            g = g1 + (g2 - g1) * blend
            b = b1 + (b2 - b1) * blend
            self.color = (int(r), int(g), int(b))

    def draw(self, surface):
        if self.life > 0:
            pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), int(self.size))

def create_explosion(particles_list, x, y):
    for _ in range(60):
        angle, speed, size, life = random.uniform(0, 2 * math.pi), random.uniform(1, 7), random.uniform(1, 5), random.randint(30, 60)
        color = random.choice([NEON_BLUE, ORANGE, WHITE])
        particles_list.append(Particle(x, y, color, size, life, angle, speed))

stars = [{"x": random.randint(0, SCREEN_WIDTH), "y": random.randint(0, SCREEN_HEIGHT), "speed": random.uniform(0.5, 2)} for _ in range(150)]
def update_and_draw_starfield(surface):
    surface.fill(BLACK)
    for star in stars:
        star["y"] += star["speed"]
        if star["y"] > SCREEN_HEIGHT: star["y"], star["x"] = 0, random.randint(0, SCREEN_WIDTH)
        brightness = int(100 + star["speed"] * 75); color = (brightness, brightness, brightness)
        pygame.draw.circle(surface, color, (star["x"], star["y"]), int(star["speed"]))

def draw_text_wrapped(text, font, color, surface, rect):
    words = text.split(' '); lines = []; current_line = ""
    for word in words:
        test_line = current_line + word + " "
        if font.size(test_line)[0] < rect.width: current_line = test_line
        else: lines.append(current_line); current_line = word + " "
    lines.append(current_line); y = rect.top
    for line in lines:
        text_surface = font.render(line, True, color)
        text_rect = text_surface.get_rect(centerx=rect.centerx, top=y)
        surface.blit(text_surface, text_rect); y += font.get_height() + 5

def admin_panel():
    wiped_message, running = "", True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: running = False
                if event.key == pygame.K_w:
                    try:
                        with open(SCOREBOARD_FILE, 'w') as f: json.dump({}, f)
                        wiped_message = "Scores wiped!"
                    except Exception as e: wiped_message = f"Error: {e}"
        update_and_draw_starfield(screen); title_text = font.render("ADMIN PANEL", True, NEON_PINK); screen.blit(title_text, (SCREEN_WIDTH//2-title_text.get_width()//2, 200))
        wipe_text = small_font.render("Press 'W' to Wipe Scores", True, NEON_BLUE); screen.blit(wipe_text, (SCREEN_WIDTH//2-wipe_text.get_width()//2, 280))
        exit_text = small_font.render("Press 'ESC' to Return", True, NEON_BLUE); screen.blit(exit_text, (SCREEN_WIDTH//2-exit_text.get_width()//2, 320))
        if wiped_message:
            feedback_text = font.render(wiped_message, True, NEON_GREEN); screen.blit(feedback_text, (SCREEN_WIDTH//2-feedback_text.get_width()//2, 400))
        pygame.display.flip(); clock.tick(FPS)

def get_player_id():
    player_id_str, input_active, error_message = "", True, ""
    konami_code = [pygame.K_UP, pygame.K_UP, pygame.K_DOWN, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT, pygame.K_LEFT, pygame.K_RIGHT]
    key_sequence, scores = [], load_scores()
    while input_active:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key in konami_code:
                    key_sequence.append(event.key)
                    if len(key_sequence) > len(konami_code): key_sequence.pop(0)
                    if key_sequence == konami_code: admin_panel(); scores, key_sequence, player_id_str, error_message = load_scores(), [], "", ""
                if event.key == pygame.K_RETURN and player_id_str:
                    if player_id_str in scores: error_message, player_id_str = "ID already taken!", ""
                    else: input_active = False
                elif event.key == pygame.K_BACKSPACE: player_id_str, error_message = player_id_str[:-1], ""
                elif event.unicode.isalnum() and len(player_id_str) < 4: player_id_str += event.unicode.upper(); error_message = ""
        update_and_draw_starfield(screen); prompt_text = font.render("ENTER ID:", True, NEON_BLUE); screen.blit(prompt_text, (SCREEN_WIDTH//2-prompt_text.get_width()//2, 200))
        id_text = font.render(player_id_str, True, NEON_GREEN); screen.blit(id_text, (SCREEN_WIDTH//2-id_text.get_width()//2, 260))
        if error_message:
            error_text = small_font.render(error_message, True, NEON_PINK); screen.blit(error_text, (SCREEN_WIDTH//2-error_text.get_width()//2, 300))
        pygame.display.flip(); clock.tick(FPS)
    return player_id_str

def load_scores():
    try:
        with open(SCOREBOARD_FILE, 'r') as f: return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError): return {}
def save_score(user_id, new_score):
    scores = load_scores()
    if new_score > scores.get(user_id, 0):
        scores[user_id] = new_score; f = open(SCOREBOARD_FILE, 'w'); json.dump(scores, f, indent=4); f.close()
def display_scoreboard(current_user_id):
    scores, sorted_scores, showing = load_scores(), sorted(load_scores().items(), key=lambda i: i[1], reverse=True), True
    while showing:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and (event.key == pygame.K_ESCAPE or event.key == pygame.K_h): showing = False
        update_and_draw_starfield(screen); title = font.render("HIGH SCORES", True, NEON_GREEN); screen.blit(title, (SCREEN_WIDTH//2-title.get_width()//2, 50))
        for i, (user_id, score) in enumerate(sorted_scores[:10]):
            color = NEON_GREEN if user_id == current_user_id else NEON_PINK
            txt = f"{i+1}. {user_id}   {score}"; line = small_font.render(txt, True, color); screen.blit(line, (SCREEN_WIDTH//2-line.get_width()//2, 120 + i*30))
        pygame.display.flip(); clock.tick(FPS)

# --- [NEW] Control Selection Menu Function ---
def get_control_scheme():
    """
    Displays a menu to select the control scheme.
    Returns: "keyboard" or "wii"
    """
    # Check if a joystick (Wii Board) is connected
    joystick_count = pygame.joystick.get_count()
    wii_board_detected = joystick_count > 0
    
    if wii_board_detected:
        try:
            # Just quickly check if we can get a name
            temp_joy = pygame.joystick.Joystick(0)
            board_name = temp_joy.get_name()
            print(f"Found joystick: {board_name}")
            temp_joy.quit() # We don't init it yet
        except pygame.error:
            wii_board_detected = False # Failed to get name, disable it
            
    choosing = True
    while choosing:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    print("Keyboard controls selected.")
                    return "keyboard"
                if event.key == pygame.K_2 and wii_board_detected:
                    print("Wii Board controls selected.")
                    return "wii"

        update_and_draw_starfield(screen)
        title_text = font.render("SELECT CONTROLS", True, NEON_BLUE)
        screen.blit(title_text, (SCREEN_WIDTH//2-title_text.get_width()//2, 200))
        
        # Option 1: Keyboard
        key_text = small_font.render("Press '1' for Keyboard", True, NEON_GREEN)
        screen.blit(key_text, (SCREEN_WIDTH//2-key_text.get_width()//2, 280))

        # Option 2: Wii Board
        wii_color = NEON_GREEN if wii_board_detected else GREY
        wii_text_str = "Press '2' for Wii Board"
        if not wii_board_detected:
            wii_text_str = "Wii Board (Not Detected)"
            
        wii_text = small_font.render(wii_text_str, True, wii_color)
        screen.blit(wii_text, (SCREEN_WIDTH//2-wii_text.get_width()//2, 320))

        if not wii_board_detected:
            hint_text = small_font.render("(Pair in Pi Bluetooth settings and restart)", True, NEON_PINK)
            screen.blit(hint_text, (SCREEN_WIDTH//2-hint_text.get_width()//2, 360))

        pygame.display.flip()
        clock.tick(FPS)
# --- [END NEW] ---

class Player:
    def __init__(self):
        self.width, self.height, self.x, self.y = 35, 35, SCREEN_WIDTH//2, SCREEN_HEIGHT-100
        self.speed, self.trail_particles, self.has_shield, self.tilt, self.target_tilt = PLAYER_SPEED, [], False, 0, 0
    def move(self, direction):
        if direction == "left": self.x -= self.speed; self.target_tilt = 20
        elif direction == "right": self.x += self.speed; self.target_tilt = -20
        self.x = max(self.width, min(SCREEN_WIDTH - self.width, self.x))
    def update(self):
        self.tilt += (self.target_tilt - self.tilt) * 0.1
        if abs(self.tilt) < 0.1: self.tilt = 0
        self.target_tilt = 0; exhaust_color = GOLD if self.has_shield else NEON_BLUE
        self.trail_particles.append(Particle(self.x, self.y+20, exhaust_color, random.uniform(2,4), 20, math.pi/2+random.uniform(-0.2,0.2), random.uniform(2,4)))
        [p.update() for p in self.trail_particles]; self.trail_particles = [p for p in self.trail_particles if p.life > 0]
    def draw(self):
        [p.draw(screen) for p in self.trail_particles]
        surf = pygame.Surface((50,50), pygame.SRCALPHA); center = 25
        body = [(center, center-18), (center-15, center+15), (center+15, center+15)]
        engine = [(center-8, center+12), (center+8, center+12), (center+6, center+18), (center-6, center+18)]
        wing_l = [(center-13, center+13), (center-22, center+10), (center-10, center+2)]
        wing_r = [(center+13, center+13), (center+22, center+10), (center+10, center+2)]
        pygame.draw.polygon(surf, (40,40,40), engine); pygame.draw.polygon(surf, NEON_BLUE, wing_l); pygame.draw.polygon(surf, NEON_BLUE, wing_r)
        pygame.draw.polygon(surf, (80,80,255), body); pygame.draw.polygon(surf, WHITE, [(center, center-12), (center-3, center-2), (center+3, center-2)])
        rot_surf = pygame.transform.rotate(surf, self.tilt); new_rect = rot_surf.get_rect(center=(self.x, self.y+10)); screen.blit(rot_surf, new_rect.topleft)
        if self.has_shield:
            sh_surf = pygame.Surface((80,80), pygame.SRCALPHA); pygame.draw.circle(sh_surf, (*GOLD, 100), (40,40), 38, 2)
            pygame.draw.circle(sh_surf, (*GOLD, 50), (40,40), 40); screen.blit(sh_surf, (self.x-40, self.y-15))

class Obstacle:
    def __init__(self, game_time, obs_type=None, x_pos=None, y_pos=None, width=None, is_fire_wall=False):
        self.is_fire_wall = is_fire_wall; self.type = obs_type or random.choice(['asteroid','drone','scout'])
        self.size = random.randint(35, 55); self.rotation_angle = random.randint(0,360); self.rotation_speed = random.uniform(-2,2)
        self.anim_timer = random.randint(0,120)
        if self.type == 'asteroid': self.width, self.height, self.points = self.size, self.size, self._generate_asteroid_points()
        elif self.type == 'drone': self.width, self.height = 45, 35
        elif self.type == 'scout': self.width, self.height, self.trail_particles = 25, 35, []
        elif self.type == 'fire_wall_segment': self.width, self.height, self.fire_particles, self.noise = width, 25, [], PerlinNoise(octaves=2, seed=random.randint(0,10000))
        self.x, self.y = x_pos or random.randint(0, SCREEN_WIDTH-self.width), y_pos or -self.height
        self.speed = 4 if self.is_fire_wall else OBSTACLE_SPEED + (game_time//1000)*0.5
        self.x_speed = 0

    def _generate_asteroid_points(self):
        pts, num_verts = [], random.randint(7,12)
        for i in range(num_verts):
            angle, dist = (i/num_verts)*2*math.pi, self.size/2*random.uniform(0.8,1.2); pts.append((dist*math.cos(angle), dist*math.sin(angle)))
        return pts

    def update(self):
        self.y += self.speed
        self.x += self.x_speed
        self.rotation_angle = (self.rotation_angle+self.rotation_speed)%360; self.anim_timer += 1
        if self.type == 'scout':
            self.trail_particles.append(Particle(self.x+self.width/2, self.y, ORANGE, 2, 15, -math.pi/2, 2))
            [p.update() for p in self.trail_particles]; self.trail_particles = [p for p in self.trail_particles if p.life>0]
        
        if self.type == 'fire_wall_segment':
            for _ in range(10):
                px = self.x + random.uniform(0, self.width)
                py = self.y + random.uniform(0, self.height / 2)
                noise = self.noise([px * 0.05, pygame.time.get_ticks() * 0.002])
                
                life = 20 + int(abs(noise * 25))
                speed = -1.2 - abs(noise * 2.5)
                angle = -math.pi / 2 + noise * 0.6
                size = 2 + abs(noise * 4)
                
                self.fire_particles.append(Particle(px, py, (0,0,0), size, life, angle, speed, color_palette=FIRE_COLORS))
                
            [p.update() for p in self.fire_particles]; self.fire_particles = [p for p in self.fire_particles if p.life>0]
            
    def draw(self, fire_surface):
        cx, cy = self.x + self.width / 2, self.y + self.height / 2
        if self.type == 'asteroid':
            rot_pts = [(cx + px * math.cos(math.radians(self.rotation_angle)) - py * math.sin(math.radians(self.rotation_angle)),
                        cy + px * math.sin(math.radians(self.rotation_angle)) + py * math.cos(math.radians(self.rotation_angle))) for px, py in self.points]
            pygame.draw.polygon(screen, (50, 50, 60), rot_pts)
            pygame.draw.polygon(screen, (180, 180, 220), rot_pts, 3)
            pygame.draw.circle(screen, NEON_BLUE, (cx, cy), 4)
        elif self.type == 'drone':
            pincer = 20 + math.sin(self.anim_timer * 0.05) * 8
            pygame.draw.polygon(screen, (80, 0, 0), [(cx, self.y), (self.x, self.y + self.height), (self.x + self.width, self.y + self.height)])
            pygame.draw.line(screen, RED, (cx, self.y), (self.x - pincer, self.y + self.height / 1.5), 4)
            pygame.draw.line(screen, RED, (cx, self.y), (self.x + self.width + pincer, self.y + self.height / 1.5), 4)
            eye = 4 + math.sin(self.anim_timer * 0.1) * 2
            pygame.draw.circle(screen, ORANGE, (cx, self.y + 15), eye)
        elif self.type == 'scout':
            [p.draw(screen) for p in self.trail_particles]
            pts = [(cx, self.y), (self.x, self.y + self.height), (self.x + self.width, self.y + self.height)]
            pygame.draw.polygon(screen, PURPLE, pts)
            pygame.draw.polygon(screen, NEON_PINK, pts, 2)

        elif self.type == 'fire_wall_segment':
            # This base surface provides a subtle, glowing heat haze behind the particles
            base_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            for i in range(15):
                pygame.draw.circle(base_surface, (RED[0], ORANGE[1], 0, 15), (random.randint(0, self.width), random.randint(0, self.height)), random.randint(15, 30))
            screen.blit(base_surface, (self.x, self.y))

            # The real fire effect comes from drawing the particles onto the additive surface
            for p in self.fire_particles:
                p.draw(fire_surface)

            # --- Draw the solid emitter bar for clarity ---
            emitter_color = (100, 100, 110)  # A dark, metallic grey
            pygame.draw.rect(screen, emitter_color, (self.x, self.y, self.width, self.height))

            # --- Draw the glowing inner edge to define the gap ---
            glow_color = GOLD  # Bright, high-contrast color
            # If the wall segment starts at x=0, it's a left segment. Its inner edge is on the right.
            if self.x == 0:
                pygame.draw.line(screen, glow_color, (self.x + self.width - 2, self.y), (self.x + self.width - 2, self.y + self.height), 4)
            # Otherwise, it's a right segment. Its inner edge is on the left.
            else:
                pygame.draw.line(screen, glow_color, (self.x, self.y), (self.x, self.y + self.height), 4)


    def off_screen(self): return self.y > SCREEN_HEIGHT

class Powerup:
    def __init__(self):
        self.size, self.x, self.y = 25, random.randint(0,SCREEN_WIDTH-25), -25
        self.speed, self.rotation_angle, self.glow_radius, self.glow_direction = POWERUP_SPEED, 0, 0, 1
    def move(self):
        self.y += self.speed; self.rotation_angle = (self.rotation_angle+5)%360; self.glow_radius += self.glow_direction
        if self.glow_radius >= 10 or self.glow_radius <= 0: self.glow_direction *= -1
    def draw(self):
        cx, cy = self.x+self.size//2, self.y+self.size//2; glow_surf = pygame.Surface((self.size+20,self.size+20), pygame.SRCALPHA)
        pygame.draw.circle(glow_surf, (*NEON_GREEN,50), (glow_surf.get_width()//2, glow_surf.get_height()//2), self.size//2+self.glow_radius); screen.blit(glow_surf, (cx-glow_surf.get_width()//2, cy-glow_surf.get_height()//2))
        cross_surf = pygame.Surface((self.size,self.size), pygame.SRCALPHA); pygame.draw.rect(cross_surf, NEON_GREEN, (0,self.size//2-2,self.size,4)); pygame.draw.rect(cross_surf, NEON_GREEN, (self.size//2-2,0,4,self.size))
        rot_surf = pygame.transform.rotate(cross_surf, self.rotation_angle); screen.blit(rot_surf, rot_surf.get_rect(center=(cx,cy)))
    def off_screen(self): return self.y > SCREEN_HEIGHT

def ask_question():
    q, selected = random.choice(questions), None
    while selected is None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1: selected = 0
                elif event.key == pygame.K_2: selected = 1
                elif event.key == pygame.K_3: selected = 2
        update_and_draw_starfield(screen)
        question_rect = pygame.Rect(50, 150, SCREEN_WIDTH - 100, 200)
        draw_text_wrapped(q["question"], small_font, NEON_BLUE, screen, question_rect)
        for i, opt in enumerate(q["options"]):
            option_rect = pygame.Rect(50, 250 + i * 50, SCREEN_WIDTH - 100, 50)
            draw_text_wrapped(f"{i+1}. {opt}", small_font, NEON_PINK, screen, option_rect)
        pygame.display.flip(); clock.tick(FPS)
    return selected == q["correct"]

def start_firewall_event(obstacles_list, powerups_list, game_time):
    obstacles_list.clear(); powerups_list.clear()
    num_walls, gap_width, last_gap_x = 5, 140, SCREEN_WIDTH // 2
    firewall_pairs = []

    for i in range(num_walls):
        min_x = max(50, last_gap_x - 200)
        max_x = min(SCREEN_WIDTH - gap_width - 50, last_gap_x + 200)
        gap_x = random.randint(min_x, max_x)
        y_pos = -100 - (i * 300)
        last_gap_x = gap_x

        left = Obstacle(game_time, 'fire_wall_segment', 0, y_pos, gap_x, True)
        right = Obstacle(game_time, 'fire_wall_segment', gap_x + gap_width, y_pos, SCREEN_WIDTH - (gap_x + gap_width), True)

        x_speed = random.uniform(1.0, 2.5) * random.choice([-1, 1])
        left.x_speed = x_speed
        right.x_speed = x_speed
        
        obstacles_list.extend([left, right])
        firewall_pairs.append((left, right))

    last_wall = firewall_pairs[-1][0] if firewall_pairs else None
    return firewall_pairs, last_wall

# --- [MODIFIED] Main Function ---
def main():
    user_id = get_player_id()
    
    # --- [NEW] Get control scheme and initialize Wii Board if chosen ---
    control_method = get_control_scheme()
    wii_board = None
    
    if control_method == "wii":
        try:
            # Assumes the board is the first joystick (index 0)
            wii_board = pygame.joystick.Joystick(0) 
            wii_board.init()
            print(f"✅ Successfully initialized joystick: {wii_board.get_name()}")
            print("Ready to use Wii Board + Keyboard for controls!")
        except pygame.error as e:
            print(f"⚠️ Failed to initialize joystick: {e}")
            wii_board = None # Fallback
            control_method = "keyboard" # Force keyboard mode
    # --- [END NEW] ---

    while True:
        player = Player(); obstacles, powerups, particles = [], [], []
        score, game_time, game_over, score_saved = 0.0, 0, False, False
        combo, combo_timer, MAX_COMBO_TIME = 1.0, 0, FPS*1.5
        
        firewall, last_wall, firewall_warn = False, None, 0
        firewall_pairs = []

        try: pygame.mixer.music.play(-1)
        except: print("Could not play music.")
        explosion, dead_sound_played = False, False
        running = True
        while running:
            clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    # --- [MODIFIED] Safely quit joystick module ---
                    pygame.joystick.quit()
                    pygame.quit()
                    sys.exit()
                if game_over and not particles and event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r: running = False 
                    if event.key == pygame.K_h: display_scoreboard(user_id)
            
            if not game_over:
                game_time += 1

                # --- [NEW] Control Scheme Input Logic ---
                
                # Mode 1: Wii Board + Keyboard Fallback
                if control_method == "wii":
                    board_active = False
                    if wii_board:
                        try:
                            # Axis 0 is typically X-axis. Try get_axis(1) if 0 doesn't work.
                            tilt = wii_board.get_axis(0) 
                        except pygame.error:
                            print("Error reading board axis. Disabling board.")
                            wii_board = None # Stop trying to read from board
                            tilt = 0.0

                        deadzone = 0.3 # Prevents accidental movement

                        if tilt < -deadzone:
                            player.move("left")
                            board_active = True
                        elif tilt > deadzone:
                            player.move("right")
                            board_active = True

                    # Fallback to keyboard if board isn't tilted or connected
                    if not board_active:
                        keys = pygame.key.get_pressed()
                        player.target_tilt = 0
                        if keys[pygame.K_LEFT]: 
                            player.move("left")
                        if keys[pygame.K_RIGHT]: 
                            player.move("right")
                
                # Mode 2: Keyboard Only
                else: # control_method == "keyboard"
                    keys = pygame.key.get_pressed()
                    player.target_tilt = 0
                    if keys[pygame.K_LEFT]: 
                        player.move("left")
                    if keys[pygame.K_RIGHT]: 
                        player.move("right")
                
                player.update()
                # --- [END NEW] ---


                if firewall:
                    if last_wall and last_wall.y > SCREEN_HEIGHT:
                        firewall = False
                        firewall_pairs = []
                    
                    for left_seg, right_seg in firewall_pairs:
                        gap_start = left_seg.x + left_seg.width
                        if gap_start < 50 or gap_start > SCREEN_WIDTH - 140 - 50:
                            left_seg.x_speed *= -1
                            right_seg.x_speed *= -1
                else:
                    if random.randint(1,120) < 5: obstacles.append(Obstacle(game_time))
                    if random.randint(1,600) < 2: powerups.append(Powerup())
                    if score >= 200 and random.randint(1,1500) == 1:
                        firewall, firewall_warn = True, 90
                        firewall_pairs, last_wall = start_firewall_event(obstacles, powerups, game_time)

                score += (1/FPS)*combo
                [obs.update() for obs in obstacles]; obstacles = [o for o in obstacles if not o.off_screen()]
                [pup.move() for pup in powerups]; powerups = [p for p in powerups if not p.off_screen()]
                
                player_rect = pygame.Rect(player.x-player.width/2, player.y, player.width, player.height)
                graze_rect, grazed = player_rect.inflate(60,60), False
                for obs in obstacles[:]:
                    obs_rect = pygame.Rect(obs.x, obs.y, obs.width, obs.height)
                    if player_rect.colliderect(obs_rect):
                        if player.has_shield: obstacles.remove(obs); player.has_shield = False
                        else: game_over = True
                    elif graze_rect.colliderect(obs_rect) and not firewall:
                        combo, combo_timer, grazed = min(5.0, combo+0.05), MAX_COMBO_TIME, True
                
                if not grazed and not firewall:
                    combo_timer -= 1
                    if combo_timer <= 0: combo = max(1.0, combo-0.05)
                
                for pup in powerups[:]:
                    if player_rect.colliderect(pygame.Rect(pup.x,pup.y,pup.size,pup.size)):
                        powerups.remove(pup); create_explosion(particles, pup.x+pup.size/2, pup.y+pup.size/2)
                        if ask_question(): score += 50; player.has_shield = True
            
            update_and_draw_starfield(screen)
            if game_over and not explosion:
                create_explosion(particles, player.x, player.y+15); explosion = True; pygame.mixer.music.stop()
                if dead_sound and not dead_sound_played: dead_sound.play(); dead_sound_played = True
            
            fire_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            fire_surface.set_colorkey(BLACK)

            if not game_over:
                [p.update() for p in particles]; [p.draw(screen) for p in particles]
                particles = [p for p in particles if p.life>0]
                player.draw()
                for obs in obstacles:
                    obs.draw(fire_surface)
                [p.draw() for p in powerups]
                
                screen.blit(fire_surface, (0,0), special_flags=pygame.BLEND_RGB_ADD)
                
                score_txt = font.render(f"SCORE: {int(score)}", True, WHITE); screen.blit(score_txt, (10,10))
                if not firewall:
                    combo_color = GOLD if combo >= 5.0 else ORANGE
                    combo_txt = font.render(f"{combo:.1f}x", True, combo_color); screen.blit(combo_txt, (SCREEN_WIDTH-combo_txt.get_width()-10, 10))
                if firewall_warn > 0:
                    warn_txt = big_font.render("!! FIRE WALL !!", True, RED); screen.blit(warn_txt, (SCREEN_WIDTH//2-warn_txt.get_width()//2, SCREEN_HEIGHT//2-50)); firewall_warn -= 1
            
            elif game_over:
                [p.update() for p in particles]; [p.draw(screen) for p in particles]
                particles = [p for p in particles if p.life>0]
                if not particles:
                    if not score_saved: save_score(user_id, int(score)); score_saved = True
                    go_txt = font.render("GAME OVER", True, NEON_PINK); screen.blit(go_txt, (SCREEN_WIDTH//2-go_txt.get_width()//2, 220))
                    final = small_font.render(f"Final Score: {int(score)}", True, WHITE); screen.blit(final, (SCREEN_WIDTH//2-final.get_width()//2, 270))
                    restart = small_font.render("R to Play Again", True, NEON_BLUE); screen.blit(restart, (SCREEN_WIDTH//2-restart.get_width()//2, 320))
                    hs_txt = small_font.render("H for High Scores", True, NEON_BLUE); screen.blit(hs_txt, (SCREEN_WIDTH//2-hs_txt.get_width()//2, 350))
            
            pygame.display.flip()

        if game_over:
            # We don't need to ask for control scheme again, just for a new ID if they restart.
            keys = pygame.key.get_pressed()
            if keys[pygame.K_r]:
                 user_id = get_player_id()
                 # No need to re-init joysticks, the main() function holds them.

if __name__ == "__main__":
    main()
